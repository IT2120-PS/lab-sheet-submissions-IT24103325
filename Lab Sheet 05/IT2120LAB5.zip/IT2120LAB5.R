setwd("C:\\Users\\IT24103325\\Desktop\\IT24103325Lab5")
Delivery_Times<-read.csv("Exercise - Lab 05.txt", header=TRUE, sep = ",")
head(Delivery_Times)


breaks <- seq(20, 70, length.out = 10)


hist(Delivery_Times$Delivery_Time_.minutes, 
     breaks = breaks, 
     right = FALSE,
     col = "lightblue",
     border = "black",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")


h <- hist(Delivery_Times$Delivery_Time_, breaks = breaks, right = FALSE, plot = FALSE)

s
cum_freq <- cumsum(h$counts)


plot(h$breaks[-1], cum_freq, type = "o", col = "blue",
     main = "Cumulative Frequency Polygon",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency"